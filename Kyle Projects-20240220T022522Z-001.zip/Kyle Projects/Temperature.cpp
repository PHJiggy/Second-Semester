#include <iostream>

using namespace std;

const int MAXR = 12;
const int MAXC = 2;

void highLow(int year[][MAXC])
{
    //i is high
    for(int i = 0; i < 12; ++i)
    {
        cout << "Enter the High Temp of "<< i+1 << ": ";
        cin >> year[i][0];
    }

    cout << endl;

    // j is for low
    for (int j = 0; j < 12; ++j)
    {
        
        cout << "Enter the Low Temp of " << j+1 << ": ";
        cin >> year[j][1];
    }
    
    
}

float addH(int year[][2])
{
    float average;
    int sum = 0;
    for(int i = 0; i < 12; ++i)
    {
        sum = sum + year[i][0];
    }

    average = sum/12.0;
    return average;
}

float addL(int year[][2])
{
    float average;
    int sum;
    for(int i = 0; i < 12; ++i)
    {
        sum = sum + year[i][1];
    }
        average = sum/12.0;
        return average;
}






int main()
{
    int year[MAXR][MAXC];
    float averageH;
    float averageL;
    
    /*string month[12];

    for(int i = 0; i < 11; ++i)
        {
            cout << "Enter the month: ";
            cin >> month[i];
        }*/
    highLow(year);
    averageH = addH(year);
    averageL = addL(year);
    
    cout << " The average of High: " << endl;

    cout << averageH << endl;

    cout << "The average of Low: " << endl; 

    cout << averageL;



    
    

}