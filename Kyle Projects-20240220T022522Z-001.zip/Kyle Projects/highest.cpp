#include <iostream>

using namespace std;

int main()
{
    int many;
    int grade[10];

    cout << "Many: ";
    cin >> many;

    for(int i = 0; i < many; ++i)
    {
        cout << "Enter the grade of " << i+1 << " :";
        cin >> grade[i];
    }

    int high = grade[0];

    for(int i = 0; i < many; ++i)
    {
        if(high < grade[i])
        {
            high = grade[i];
        }
    } 

cout << "The highest is " << high;
}