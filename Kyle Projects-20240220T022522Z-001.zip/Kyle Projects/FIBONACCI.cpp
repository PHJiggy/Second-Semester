#include <iostream>
#include <cmath>

using namespace std;

int fiboF(int user)
{
   int i = 0;
   int Fi2 = 1;         
   int Fi1 = 0;
   int result;

   while(i<user)
   {

    result = Fi1 + Fi2;
    Fi1 = Fi2;
    Fi2 = result;

    i++;

   }

return result;



}

int main()
{
    int positiveN;
    int Ffibo;

    cout << " Enter a positive Number: ";
    cin >> positiveN;


    Ffibo = fiboF(positiveN);


    cout << " The fibonacci is " << Ffibo << endl;

}