#include <iostream>

using namespace std;

void searching(int const storage[5], int search)
{
    for(int i=0; i < 5; ++i)
    {
        if(storage[i] == search)
        {
            cout << endl << "Your data is in storage " << i+1; 

        }else{
            cout << endl << "Your data not available! in " << i+1 ;
        }
    }

}


int main()
{
    int searchfor;
    int storage[5];
    
    
    for(int i = 0; i < 5; ++i)
    {
        cout << "Enter a value in Storage " << i+1 << " :  ";
        cin >> storage[i];
        system("CLS");

    } 

    cout << "Search where your data located: " << endl;
    cin >> searchfor;


    searching(storage, searchfor);
}