#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int a;
    int b;
    int c;

    cout << " Enter the Value for a: ";
    cin >> a;
    cout << " Enter the value for b: ";
    cin >> b;
    cout << " Enter the value for c: ";
    cin >> c;

    if(b >=0 && c >= 0)
    {
        cout << "There is no solution for x."
    }

    
}