#include <iostream>

using namespace std;

const int MAXR = 100;
const int MAXC = 100;

void getdata(int Fnum[][MAXC], int row, int col)
{
    for (int i = 0; i < row; ++i)
    {
        for(int j = 0; j < col; ++j)
        {
            cout << "Enter the integer in Row " << i + 1 << " and Column " << j+1 << " : ";
            cin >> Fnum[i][j];
        }
    }
    
}

void data_list(int Fnum[][MAXC], int row, int col)
{
    for(int i = 0; i < row; ++i)
    {
        for(int j= 0; j < col; ++j)
        {
            cout << " Row " << i+1 << " and Column "<< j+1 << " is " << Fnum[i][j] << endl;
        }
    }
}

void adding_row(int Fnum[][MAXC], int row, int col)
{
    int adding;
    for(int i = 0; i < row; ++i)
    {
        adding = 0;
        for(int j = 0; j < col; ++j)
            adding = adding + Fnum[i][j];
            cout << adding << " ";
        
    }
}

void adding_col(int Fnum[][MAXC], int row, int col)
{
    for (int  i = 0; i < col; ++i)
    {
        int sum = 0;
        for(int j = 0; j < row; ++j)
        {
            sum = sum + Fnum[i][j];

            cout << " COLUMN SUM: " << sum;
        }
    }
    
}


int main()
{
    int num[MAXR][MAXC];
    int col;
    int row;

    cout << "Enter : ";
    cin >> row;

    col = row;
    while(row > MAXR)
    {
            cout << "Invalid! " << endl;
            cout << "Enter : ";
            cin >> row;
    }

     getdata(num,row,col);
     data_list(num, row, col);
     adding_row(num,row,col);
     adding_col(num,row,col);


}