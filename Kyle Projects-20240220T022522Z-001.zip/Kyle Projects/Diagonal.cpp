#include <iostream>

using namespace std;

int const ROW = 100;
int const COL = 100;

int Irow()
{
    int row;
    cout << "Enter the row: ";
    cin >> row;
    
    return row;
}

int Icol()
{
    int col;

    cout << "Enter the column: ";
    cin >> col;

    return col;
}

void Fmatrix(int matrix[][COL], int row, int col)
{   
    for(int i=0; i < row; ++i)
    {
        for(int j=0; j < col; ++j)
        {
            cout << "Enter the Row " << i+1 << " and Column " << j+1 << " : ";
            cin >> matrix[i][j];
        }
    }

}


int is_diagonal(int matrix[][COL], int row, int col)
{
    for(int i=0; i < row; ++i)
    {
        for(int j = 0; j < col; ++j)
        {
            if( i != j && matrix[i][j] !=0)
            {
                return 0;
            }
        }
    }
    return 1;
}


int main()
{
    int matrix[ROW][COL];
    int row;
    int col;
    int diagonal;
    
     row = Irow();
     col = Icol();

    Fmatrix(matrix,row,col);
    diagonal = is_diagonal(matrix,row,col);
    if (diagonal == 1)
    {
        cout << endl;
        cout << "The matrix is DIAGONAL!";

    }else
      {   
        cout << "The matrix is not diagonal";
      }
    
    
}