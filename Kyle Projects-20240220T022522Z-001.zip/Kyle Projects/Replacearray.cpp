#include <iostream>
const int MAXC = 100;
const int MAXR = 100;
using namespace std;

void getdata(int Fnum[][MAXC], int row, int col )
{
    for(int i = 0; i < row; ++i)
    {
        for(int j= 0; j < col; ++j)
        {
            cout << "Row " << i+1 << " and Col "<< j+1 << " : ";
            cin >> Fnum[i][j];

            
        }
    }


    for(int i = 0; i < row; ++i)
    {
        cout << endl;
        for(int j= 0; j < col; ++j)
        {
            
            cout <<Fnum[i][j] << " ";
            
        }
    }
      cout << endl;
    
}

void replace(int Fnum[][MAXC], int row, int col)
{
    for(int i= 0; i < row; ++i)
    {
        for(int j= 0; j < col; ++j)
        {
            if(Fnum[i][j] == 3)
            {
                Fnum[i][j]= 9;
                
            }
        }
    }

    for(int i = 0; i < row; ++i)
    {
        cout << endl;
        for(int j = 0; j < col; ++j)
        {
            cout << Fnum[i][j] << " ";
        }
    }
}


int main()
{
    int num[MAXR][MAXC];
    int row,col;

    cout << "Enter the limit: ";
    cin >> row;
    col = row;

    cout << "The content: " << endl;
    getdata(num,row,col);
    cout << "The replaced content: " << endl;
    replace(num,row,col);

}