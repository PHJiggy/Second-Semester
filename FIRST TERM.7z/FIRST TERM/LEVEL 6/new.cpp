//Wailinn Saw
//Guessing game
#include <iostream>
#include <ctime> //Used to seet the random seed
#include<cstdlib>//used to use the function rand.
#include <string>//Allows strings to be used.
using namespace std;

void ReverseGuessingGame();//declare a function prototype for the reverse guessing game.

int main()
{
	char name[30];//string array to store up to 1 element.
	char no, again; //used to answer the yes or no questions.
	int choice, secretNumber[1]; //Store the random number in secretNumber array, choice is for the menu options.
	int min, max;//Min and Max number
	const int num_of_guess = 10; //Set the maximum number of guests to 10.
	int player_guess[num_of_guess]; //Allows for the player to guess up to the number of guesses which is 10;
	int total_guess; //initialized total guess up here instead of in the for loop in line 88.

	cout << "What is your name? ";//Ask for the user name.
	cin.getline(name, 30);//used getling to grab charachers and ignore spaces.
	while (true)//Loop start for name validation
	{
		cout << "\nIs your name: " << name << " ? (y/n)\n";
		cin >> no;//first yes or no quesion input
		if ((no != 'y') && (no != 'Y') && (no != 'N') && (no != 'n'))//If any value is used expect for y or n
		{
			cout << "Please only say yes or no. ";
			cin.clear();
			cin.ignore(1000, '\n');
		}
		else if (no == 'n' || no == 'N')//If the value is no
		{
			cout << "What is your name? ";
			cin.clear();
			cin.ignore(1000, '\n');
			cin.getline(name, 20);
		}
		else break;//if the value is yes
	}
	while (true)
	{
		system("cls");//windows command to clear the screen and shows the menu.
		cout << "\tWelcome to the Guessing game " << name << endl;
		cout << "\nPlease select one form the following menu choices: " << endl;
		cout << "\t1. Guessing Game\n"
			<< "\t2. Reverse Guessing Game (unfinsihed)\n"
			<< "\t3. Exit the program\n";
		cin >> choice;
		if (choice == 3)//Exit the game
		{
			cout << "\nThank you for playing " << name << " good bye.\n";
			break;
		}
		else if (choice == 1)//Starts the guessing game
		{
			while (true)//This is to the loop for the whole game if the user says yes at the end.
			{
				bool badInput = true; //True or false for bad values.
				system("cls");// clears the screen 
				do//runes the program once before checking the loop
				{
					cout << "Please choose the minimum value to guess from: ";
					cin >> min;
					if (badInput = cin.fail() || (min < 0))//if the input is not a number using the bad input boolean or if less than 0.
					{
						cout << "\nPlease enter a number (not a letter) greater than 0.\n";
						cin.clear();//clear the cin value.
						cin.ignore(numeric_limits<streamsize>::max(20), '\n');//ignores the enter key, set for max size (because internet 0_o)
					}
				} while (badInput == true);//loops until the value is number.
				do//same as before but for the max number.
				{
					cout << "\nPlease choose the maximium value to guess up to: ";
					cin >> max;
					if (badInput = cin.fail() || (max <= min))
					{
						cout << "\nPlease enter a value greater than " << min << " and not a letter.\n";
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
					}
				} while (badInput == true);
				//random number generator that guesses a number from the range within the user input.
				srand(time(NULL));
				secretNumber[0] = rand() % max + min;
				system("cls");
				cout << "You have 10 trys to guess the number I picked =) Good Luck " << name << ".";
				cout << "\nPlease guess the number between " << min << " and " << max;
				for (total_guess = 0; total_guess < num_of_guess; total_guess++)//Loops the game until the total guess is 10 or the number is guessed,
				{
					cout << "\nTry #" << total_guess + 1 << " ";//will show try#1 2 3 etc..
					cin >> player_guess[total_guess];
					if (cin.fail())//Makes sure that there is no letters.
					{
						cout << "\Ynou have to guess between " << min << " and " << max;
						cout << "\nPLease try again.";
						total_guess--; //decrease the total guess count by 1
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
					}
					else if ((player_guess[total_guess] < min) || (player_guess[total_guess] > max))//Make sure they stay within bounds.
					{
						cout << "\nYou have to guess between " << min << " and " << max;
						cout << "\nPLease try again.";
						total_guess--; //decrease the total guess count by 1
					}

					else if (player_guess[total_guess] < secretNumber[0])//Guess to low
					{
						cout << "You guessed too low, try again.";
					}
					else if (player_guess[total_guess] > secretNumber[0])//Guess to high
					{
						cout << "You have guessed too high, try again.";
					}
					else if (player_guess[total_guess] == secretNumber[0])//Guess correctly
					{
						cout << "\nCongrtulations you guessed the number right!"
							<< "\nThe number is " << secretNumber[0] << "!"; //Shows the secret number
						cout << "\nIt took you a total of " << total_guess + 1 << " trys."; //Shows the number of trys
						cout << "\nyou have guessed the following numbers: ";
						for (int j = 0; j <= total_guess; j++)
						{
							cout << player_guess[j] << " ";//Shows all the guesses the player made.
						}
						total_guess = 10; //Make total guess equal to 10 to exit the for loop.
					}
					else if (total_guess = 10)//ran out of guesses.
					{
						cout << "Sorry you have ran out of guesses! XD."
							<< "\nThe number i was thinking of was " << secretNumber[0] << ".";//shows the secret number
						cout << "\nyou have guessed the following numbers: ";
						for (int j = 0; j <= total_guess; j++)
						{
							cout << player_guess[j] << " ";//outputs the player guesses
						}
					}
				}
				cout << "\n\nWould you like to try to play again for another chance to beat me? (y/n) ";
				cin >> again;
				if ((again != 'y') && (again != 'Y') && (again != 'N') && (again != 'n'))//If any value is used expect for y or n
				{
					cout << "Please only say yes or no. " << endl;
					cin.clear();
					cin.ignore(1000, '\n');
				}
				else if ((again == 'n') || (again == 'N'))//If the user chooses no break out of the game back to the menu.
				{
					break;
				}
				else continue;//if the user chooses yes continue with the loop of the game.
			}
		} //End of guessing game code
		else if (choice == 2)
		{
			ReverseGuessingGame(); //This calls the function ReverseGuessingGame and runs that function.
		}
	}//end of the whole program
	return 0;
}

//Place holder game I am testing. This is just code I found and was trying to test it and learn how it works.
//I have made changes to fit my use.
//The program will sometime keep guessing the same number.
//Missing the the check for number of guesses. 
//Does not display number of guesses.
void ReverseGuessingGame()
{
	int myNumber = 0;
	char HighOrLow, again;
	int maxNum = 0;
	int minNum = 0;
	int computerguess, max_allowed_guesses = 10;
	int i = 0;
	bool badInput = true;
	do//main loop
	{
		do//runes the program once before checking the loop
		{
			cout << "Please choose the minimum value to guess from: ";
			cin >> minNum;
			if (badInput = cin.fail() || (minNum < 0))//if the input is not a number using the bad input boolean or if less than 0.
			{
				cout << "\nPlease enter a number (not a letter) greater than 0.\n";
				cin.clear();//clear the cin value.
				cin.ignore(numeric_limits<streamsize>::max(), '\n');//ignores the enter key, set for max size (because internet 0_o)
			}
		} while (badInput == true);//loops until the value is number.
		do//same as before but for the max number.
		{
			cout << "\nPlease choose the maximium value to guess up to: ";
			cin >> maxNum;
			if (badInput = cin.fail() || (maxNum <= minNum))
			{
				cout << "\nPlease enter a value greater than " << minNum << " and not a letter.\n";
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
			}
		} while (badInput == true);
		cout << "Enter your number between " << minNum << "-" << maxNum << ": ";
		cin >> myNumber;
		while ((myNumber < minNum) || (myNumber > maxNum))
		{
			cout << "Enter your number between " << minNum << "-" << maxNum << ": ";
			cin >> myNumber;
		}
		do {
			i++;
			srand(time(NULL));
			computerguess = rand() % (maxNum - minNum) + minNum;

			if (computerguess == myNumber) {
				cout << "The computer has guessed " << myNumber << "!" << endl;
				break;
			}

			cout << "Is " << computerguess << " too high(h) or low(l)?" << endl;
			cin >> HighOrLow;

			if ((HighOrLow == 'h') || (HighOrLow == 'H'))
			{
				maxNum = computerguess;
			}
			else if ((HighOrLow == 'l') || (HighOrLow == 'L'))
			{
				minNum = computerguess;
			}
			//Tried to keep track of the numbe of guesses
			//----------------------------------------------------//
			else if (i = max_allowed_guesses)
			{
				break;
			}
			//---------------------------------------------------//
		} while (computerguess != myNumber);

		cout << "The computer has won! It took " << i << " tries." << endl;
		//i = 0;//resets the count
		cout << "\n\nWould you like to try to play again for another chance to beat me? (y/n) ";
		cin >> again;
		while ((again != 'y') && (again != 'Y') && (again != 'N') && (again != 'n'))
		{
			cout << "Please only say yes or no. " << endl;
			cin.clear();
			cin.ignore(1000, '\n');
		}
		if ((again == 'n') || (again == 'N'))//If the user chooses no break out of the game back to the menu.
		{
			break;
		}
		//Prompt if the computer gueses over the limit
		//---------------------------------------------------------------------------------------------------------------------//
		while (i = max_allowed_guesses)
		{
			cout << "\n\Looks like the computer did not guess your number! Would you like to try again? (y\n): ";
			cin >> again;
			while ((again != 'y') && (again != 'Y') && (again != 'N') && (again != 'n'))
			{
				cout << "Please only say yes or no. " << endl;
				cin.clear();
				cin.ignore(1000, '\n');
			}
			if ((again == 'n') || (again == 'N'))//If the user chooses no break out of the game back to the menu.
			{
				break;
			}
		}
		//-----------------------------------------------------------------------------------------------------------------------//
	} while ((again == 'y') || (again == 'Y'));
	system("pause");
}
