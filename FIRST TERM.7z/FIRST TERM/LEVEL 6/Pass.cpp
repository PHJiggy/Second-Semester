//password

#include <iostream>
#include <string>


using namespace std;

main()
{
     int counter = 0;
     int sum = 0;
     int number;
     while(counter < 5)
     {
     	cout << "1";
     	cout << "0";
     	cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";cout << "1";
     	cout << "0";
	 }
	
	
}
