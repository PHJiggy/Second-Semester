#include <iostream>

using namespace std;

main()
{
	int i = 0;
	while(i <= 1000000000000000000000000000000000000000000000000000000000000)
	{
	
 		cout << " " << i;
		 i = i + 1;	 
}

}
