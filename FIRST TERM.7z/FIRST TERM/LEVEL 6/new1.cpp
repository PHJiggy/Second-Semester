#include <iostream>

using namespace std;

main()
{ 
     int NumOne;
     int NumTwo;
     int NumThree;
     int max;
     
		cout << "Number 1: ";
		cin >> NumOne;
		cout << "Number 2: ";
		cin >> NumTwo;
		cout << "Number 3: " << endl;
		cin >> NumThree;
		
		if(NumOne > NumTwo)
		{
		   max = NumOne;
		}else {
			max = NumTwo;
		}
		
		if(max < NumThree)
		{
			max = NumThree;
	} 
	
	cout << max;
}

