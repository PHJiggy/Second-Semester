#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif
#include<iostream>
#include <cstdlib>

using namespace std;

int main()
{
  cout << "Before sleep call "<<endl;
  cout.flush();
  sleep(0);
  cout << "After sleep call"<< endl;

  return 0;
}
