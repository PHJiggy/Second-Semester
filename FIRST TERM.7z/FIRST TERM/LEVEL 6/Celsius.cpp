#include <iostream>

using namespace std;

main()
{
		float celsius;
		float fahrenheit;
		float user;
		
		while(user !=3)
		{
			
			cout << "==========================================" << endl;
			cout << "||               HELLO USER!!           ||" << endl;
			cout << "==========================================" << endl;
		
		cout << "\n1. Convert Celsius to Fahrenheit "<< endl;
		cout << "2. Convert Fahrenheit to Celsius " << endl;
		cout << "3. Exit " << endl;
	
	
		cout << "\nEnter the number of your choice : ";
		cin >> user;
		
		
		
		if(user == 1)
		{
			cout << "Fahrenheit Value : ";
			cin >> fahrenheit;
			celsius = 5 / 9 * (fahrenheit) - 32;
		}
		
		if(user == 2)
		{
			cout << "Celsius Value : ";
			cin >> celsius;
			celsius = (9.0/5) * celsius - 32;
		}
	}
	
	
		if (user == 3)
		{
			cout << "You are now Exit bruh";
		} else if(user > 3){
			cout << "Invalid input";
		}
	
}
