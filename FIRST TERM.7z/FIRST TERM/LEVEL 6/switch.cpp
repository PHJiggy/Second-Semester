#include <iostream>

using namespace std;

main()
{
		float celsius;
		float fahrenheit;
		int user;
		char N;
		while(user < 3)
		
		{
			system("CLS");
			
			cout << "\n==========================================" << endl;
			cout << "||               HELLO USER!!           ||" << endl;
			cout << "==========================================" << endl;
		
		cout << "\n1. Convert Fahrenheit to Celsius "<< endl;
		cout << "2. Convert Celsius to Fahrenheit " << endl;
		cout << "3. Exit " << endl;
	
	
		cout << "\nEnter the number of your choice : ";
		cin >> user;
		
		
		switch(user)
		{
			case 1:
			cout << "Fahrenheit Value : ";
			cin >> fahrenheit;
			celsius = 5 / 9 * (fahrenheit) - 32;
			cout << "The temperature in Celsius is " << fahrenheit << endl;
			break;
			
			case 2:
			cout << "Celsius Value : ";
			cin >> celsius;
			celsius = (9.0/5) * celsius - 32;
			cout << "The temperature in Fahrenheit is " << celsius << endl;
			break;
			
			case 3:
			cout << "You are now Exit bruh";
			break;
			
		    default:
			cout << "Invalid input";
		}
		
		cout << "Press N to Continue";
		cin >> N;
}
			
	

}
