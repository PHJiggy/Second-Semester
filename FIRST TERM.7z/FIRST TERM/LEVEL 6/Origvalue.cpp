#include <iostream>

using namespace std;

main()
{ 
    float increased;
    float decreased;
    float orig_value;
    float new_value;
    
    
    while(true){
	
    cout << "\nPut the Orig Value: ";
    cin >> orig_value;
    cout << "Put the new Value: ";
    cin >> new_value;
    
    if(orig_value > new_value)
    {
    	decreased = (orig_value - new_value) / orig_value * 100; 
    	cout << "\nThe Value decreased and the percent decrease is " << decreased << endl;
	} else if(orig_value == new_value) {
		cout << "\nThe value is equal you cannot proceed" << endl;
	} else {
		increased = (new_value - orig_value) / orig_value * 100; 
		cout << "\nThe Value increased and the percent decrease is " << increased << endl;
	}
}
}

