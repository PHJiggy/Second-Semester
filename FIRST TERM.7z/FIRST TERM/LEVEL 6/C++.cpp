#include <iostream>
using namespace std;

main()
{
    cout << "Test";
}