#include <iostream>

using namespace std;

main()
{
	bool y = 1;
	bool x = 2;
	bool eq = y == x;
	
	cout << eq;
}
