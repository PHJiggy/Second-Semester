#include <iostream>

using namespace std;

main()
{
	int i;
	int j;
	int k;
	
	
	
	for(i = 0; i < 5; ++i)
	{
		for(j = 0; j < i; ++j)
		{
		cout << j;
		}
		cout << endl;	
	}
	
	
	
}
