#include <iostream>

using namespace std;

int function(int val)
{
	if (val == 0)
	{
		return 0;
	}else if(val == 1 || val == 2)
	{
		return 1;
	}
else{
	return (function(val - 1) + function(val -2));
}
}
main()
{
	
int val = 7;
for (int i = 0; i < val; i++)
{
	cout << function (i)<< " ";
}
	return 0;
}
