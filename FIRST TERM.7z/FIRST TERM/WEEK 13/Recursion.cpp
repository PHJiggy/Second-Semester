#include <iostream>

using namespace std;






int factorial(int fac)
{
  if(fac > 1)
    return fac * factorial(fac - 1);
  else
    return 1;
}














main()
{
	int user;
	
	cout << "Enter a Positive :";
	cin >> user;
	
	
	cout << "Result :  " << factorial(user);
}
