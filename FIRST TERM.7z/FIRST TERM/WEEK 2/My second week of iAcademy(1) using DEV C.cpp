#include <iostream>

// My second week in college using C++
// hehehehehehhehehehehhehehehehehehehe

using namespace std;


// This is the main.

main()
{
	cout << "hello world" /* May I welcome? di joke :>*/ << "\nMy First Program!!!"; 
	cout << "\nMy First Program!!!";
	
	cout << "Bye.";
	}
}

