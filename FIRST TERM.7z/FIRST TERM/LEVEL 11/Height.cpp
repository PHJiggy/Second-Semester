#include <iostream>

using namespace std;

const float inchesss = 12;
const float meter = 0.0254;
const float pounds = 2.2;

float height_ni_pare(float f_height, float i_height)
{
	float total_ht;
	
	total_ht = f_height * inchesss + i_height;
	return total_ht;
}

int main()
{
	
	float feet;
	float inches;
	float kg;
	float totalHI;
	float totalHM;
	float totalWP;
	
		
	
	cout << "Enter your height in feet and inches." << endl;
	cout << "Enter the feet pre    : " << endl;
	cin >> feet;
	cout << "Enter the inches pre : " << endl;
	cin >> inches;
	cout << "Pounds naman pre      : " << endl;
	cin >> kg;
	
	
	
