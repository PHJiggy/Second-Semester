#include <iostream>

using namespace std;

// i like to do coding when i want to show who I'am.
/*
// "int factorial(int fac)
{
  if(fac > 1)
    return fac * factorial(fac - 1);
  else
    return 1; 
	
	(so fac * factorial then return the answer in the factorial then fac -1
and then proceed since it doesn't meet the false condition.) i hate recursion

ever result -1 until meet the condition.

}" //

*/


main()
{
	cout << "Journal";
	
}
