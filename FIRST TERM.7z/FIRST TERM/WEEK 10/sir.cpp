#include <iostream>
using namespace std;

main ()
{
   int first, second;
   int ctr, sum;
   
   //prompt the user to enter the required input values
   cout << "Enter the first integer: ";
   cin >> first;
   cout << "Enter the second integer: ";
   cin >> second;
   
   //Ensure that the second integer is greater than the first integer
   while (first >= second) // The program should continuously prompt the user to enter the data until (second > first)
   {
   	  cout <<"\nThe second integer must be greater than the first! Please try again.";
      cout << "\n\nEnter the first integer: ";
      cin >> first;
      cout << "Enter the second integer: ";
      cin >> second;
   }
   
   //this part of the program prints all odd numbers between the first and second integers
   cout << "\n\nThe odd numbers from " << first << " and " << second << " are:  ";
   
   ctr = first;
   while (ctr <= second)
   {
      if (ctr%2 == 1)  //check if the number is odd. if odd, then print the number
	     cout << ctr << "  ";
	  ++ctr;  //to check the next number	
   	
   }
}
