#include <iostream>

using namespace std;

main()
{

int j;
int i;
int k;
int side;

 cout << "Enter : ";
 cin >> side;

string a = "* ";
int test = 0;


//1st
for(i = 1; i <= side; ++i)
{
	
	//2nd
	for(j = 1; j <= i; ++j)
	{
		cout << j << " ";
	}
	
	// 3rd
	for(k = 2; k <= side; ++k)
	{
		cout << a;
	}
	cout << endl;
}
	
}

