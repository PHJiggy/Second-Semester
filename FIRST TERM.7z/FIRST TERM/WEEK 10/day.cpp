#include <iostream>

using namespace std;

main()
{
	int month;
	int day;
	char user;
	
	cout <<"Enter the MBD : ";
	cin >> month;
	cout <<"Enter the Day : ";
	cin >> day;
	
	
	cout << "Do you want to try again? ";
	cin >> user;
	
	if(user == 'N' || user == 'n')
	{
		exit(0);
	}else if(user == 'Y' || user == 'y')
	{
		cout << "Agnas";
	}
	else{
		cout << "Y big and y small lng!";
	}
	
	
}
