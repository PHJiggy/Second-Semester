#include <iostream>

using namespace std;

main()
{
	int user_first;
	int user_second;
	int count = 0;
	int odd;
	
	cout << "Enter the first number: ";
	cin >> user_first;
	cout << "Enter the second number: ";
	cin >> user_second;
	
	
	while(user_first >= user_second)
	{
		cout << " Not valid! ";
		
		cout << "Enter the first number: ";
		cin >> user_first;
		cout << "Enter the second number: ";
		cin >> user_second;
		
	}
	
	int bro = user_first;
	
	while(bro <= user_second)
	{
		if(bro%2 == 1)
		{
			cout << "The odd number is " << bro << endl;
		}
		
		++bro;
	}
	
}
