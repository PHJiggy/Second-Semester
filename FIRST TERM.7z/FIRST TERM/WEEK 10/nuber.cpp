#include <iostream>
using namespace std;

main ()
{
		
		
		int integer;
		int value;
		bool prime;
		
		cout << " Enter an integer: ";
		cin >> integer;
		
		while(integer < 1)
		{
			cout << "The number must greater than 1!" << endl;
			
			cout << " Enter an integer: ";
			cin >> integer;
			
		 } 
		 
		 
		 value = 2;
		 while(value < integer )
		 {
		 	if(integer%value == 0)
		 	{
		 		prime = false;
		 		break;
			 }else{
		 	prime = true;
			 ++value;
		 }
		 }
		 
		 if(prime == true)
		 {
		 	cout << "the integer is a prime number";
		 }else 
		 {
		 	cout << "The integer is not a prime number";
		 }
		 
		 


}
