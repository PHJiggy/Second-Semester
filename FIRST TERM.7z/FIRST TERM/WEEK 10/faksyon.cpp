#include <iostream>

using namespace std;

int greater(int on, int tw)
{  
	if(on > tw)
	{
		return(on);
	}else 
	{
		return(tw);
	}
}

int main()
{
	int one;
	int two;
	int test;
	
	cout << "Enter the one : ";
	cin >> one;
	cout << "Enter the two : ";
	cin >> two;
	
	test = greater(on, tw);
	
	cout << " " << test;
	
	
	
}
