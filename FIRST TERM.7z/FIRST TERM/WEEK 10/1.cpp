#include <iostream>
#include <string>

using namespace std;

int main()
{

int j;
int i;
int side;

 cout << "Enter : ";
 cin >> side;

string a;
int test = 0;

for(i = 0; i <= side; ++i)
{
	a = "";
	for(j = 0; j <= side; ++j)
	{
		a += (i >= 1 && i <= 7 && j == i) ? "* " : " ";
	}
	cout << a << endl;
}
	
}
