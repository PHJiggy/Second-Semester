#include <iostream>

using namespace std;

main()
{
int ++test;
int yey++;

   cout << test << endl;
cout << yey;
	
}
