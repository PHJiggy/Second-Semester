#include <iostream>

using namespace std;

main()
{
	int base;
	int exp;
	int count = 0;
	int answer = 1;
	int i;
	
	cout << "Pre ilan yung base: ";
	cin >> base;
	cout << "Lagay mo nadin ilang Exponent: "<< endl;
	cin >> exp;
	
	for(count = 0; count < exp; ++cout)
	{
		
	}
	
}
