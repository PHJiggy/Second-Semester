#include <iostream>
#include<windows.h>

using namespace std;

main()
{
	
	int list = 1;
	int number;
	int add = 0;
	int user;
	
	
	cout << "How many number: ";
	cin >> user;
	while(user==0)
	{
	
		cout << "Paki ayos po. Di pwede 0" << endl;
		
		Sleep(3000);
		system("CLS");
		cout << "How many number: ";
	cin >> user;
		 
	}	
	
	for(int j = 0 ; j < user  ; ++j)
	{
		cout << list <<"Input a number: " << endl;
		cin >> number; 
		add = add + number;
		++list; 
	}
	
	cout << "Result: " << add;
	
}    
