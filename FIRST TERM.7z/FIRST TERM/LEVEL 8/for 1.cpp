#include <iostream>
#include <windows.h>

using namespace std;

main()
{
int j;
for(j=1; j <= 50; ++j)
{
	if(j%2 == 0)
	{
		Sleep(2000);
		cout << " The even " << j << endl;
	} else {
		Sleep(2000);
		cout << " The odd "<< j << endl;
	}
	
	
	
}

	
}
