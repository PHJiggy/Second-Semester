#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <chrono>
#include <thread>

// Function to shuffle a vector of strings randomly
void shuffleStrings(std::vector<std::string> &strVec) {
    // Seed the random number generator with the current time
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    // Shuffle the vector randomly
    std::random_shuffle(strVec.begin(), strVec.end());
}

int main() {
    std::vector<std::string> userInputs;

    while (true) {
        std::cout << "Enter a question anything you want: (or 'q' to quit): ";
        std::string userInput;
        std::getline(std::cin, userInput);

        if (userInput == "q" || userInput == "Q") {
            break; // Exit the loop if the user enters 'q' or 'Q'
        }

        userInputs.push_back(userInput); // Store the user input
    }

    // Shuffle the stored strings
    shuffleStrings(userInputs);

    // Print the randomized inputs with a cooldown
    std::cout << "Randomized inputs:" << std::endl;
    for (const std::string &input : userInputs) {
        std::cout << input << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(10)); // Add a 2-second cooldown
    }

    return 0;
}


