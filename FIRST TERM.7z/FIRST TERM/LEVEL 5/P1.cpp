#include <iostream>

using namespace std;

main ()
{
	const int passing_grade = 85;
	int grade;
	
	cout << "enter your grade: ";
	cin >> grade;
   	
   	
	   
	     if(grade >= 100)
		{
		
	   	  cout << "Don't troll bro.";
	   }
	   
	   else if(grade >= passing_grade)
	   {
			cout << "Congrats";   		
	   
}
	   
		else if(grade == 0)
	   {
	   	cout << "You not able to proceed. ";
	   }
	  
	   else {
	   	cout << "oh no. bagsak ka pre ";
	   }
   	
   	
   	
   	
   	
}
