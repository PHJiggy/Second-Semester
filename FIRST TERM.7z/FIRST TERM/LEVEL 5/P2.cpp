#include <iostream>
#include <string>
using namespace std;

main ()
{
	int user_grade;
	string result;
	
	cout << "Put your grade: ";
	cin >> user_grade;
	
	if(user_grade >= 91 && user_grade <= 100) 
	{
		result = "1.00";
	}
	
	else if(user_grade >= 81 && user_grade <=90)
	{
		result = "2.00";
	}
	
	else if(user_grade >= 70 && user_grade <=80)
	{
		result = "3.00";
	}
	
	else if(user_grade >= 0 && user_grade <=69)
	{
		result = "5.00";
		
	} else
	{
		cout << "Bruh why you get -1? ";
	}
	
	cout << "The result is " << result;
	
	
	 int result_finish = stoi(result);
	 
	 
	
	
}
