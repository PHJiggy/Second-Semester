#include <iostream>
using namespace std;

#define PI 3.1416


main()

{

	float radius;
	float area;
	
	cout << "Put the number: ";
	cin >> radius;
	area = PI * radius * radius;
	
	cout << "Result: "<< area;
	
	
}
