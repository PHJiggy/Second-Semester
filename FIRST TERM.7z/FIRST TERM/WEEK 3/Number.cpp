#include <iostream>
using namespace std;

main()
{
	double php = 56.77; // the amount of the dollar
	float usd; //this is the variable input of the user
	cout << "Please input the dollar amount: ";
	cin >> usd; // asking to the user the amount of dollars that he/she want to covernt into pesos
	
	cout << "Amount of the dollar in Pesos is: " << usd * php << "Php"; //the result
	
}
