#include <iostream>

// My second week in college using C++
// hehehehehehhehehehehhehehehehehehehe

using namespace std;


// This is the main.

main()
{
	int gross, net, cost;
	float kyle, spike;
	bool iAcademy, Benthel;
	
	iAcademy = true;
	Benthel = false;
	
	kyle = 1.9;
	spike = 1.2;
	gross = 100;
	cost = 10;
	net = gross - cost;
	char user[2];
	
	cout << "The net is " << net << endl;
	cout << "then put: ";
	cin >> user;
	
	if(user[0] = 'kyle'){
		cout << kyle;} else
	  if(user = 'spike'){
		cout << spike;
	}else {cout << "end";
	}
}

	
	


