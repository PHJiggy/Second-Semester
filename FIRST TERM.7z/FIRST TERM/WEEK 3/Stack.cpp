#include <iostream>
using namespace std;

int main(){

    int newOne = 5;
    int back = 3;
    float sum = newOne / back;
    float newVar = sum;
    
    cout << newVar << endl;
    
}
