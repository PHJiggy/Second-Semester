#include <iostream>
using namespace std;

int main(){
	
    const float Gravity = 6.673e-8; 
    float massOne;
    float massTwo;
    float dist;
    float compute = Gravity * massOne * massTwo /(dist * dist);
    
    cout << "put a two mass: ";
    cin >> massOne;
    
    cout << "put the mass: ";
    cin >> massTwo;
    
    cout << "distance: ";
    cin >> dist;
    
    
    
    cout << "Result: " << compute;
    
}
