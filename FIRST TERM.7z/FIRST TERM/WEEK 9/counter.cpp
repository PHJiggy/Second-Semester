#include <iostream>

using namespace std;

main()
{
float user;
int count = 0;


cout << "Number: ";
cin >> user;

while(user > 0)
{
user = user/10;
++count;

}


cout << "Result " << count << " Digit ";


}
