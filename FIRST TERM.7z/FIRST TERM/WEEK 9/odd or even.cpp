#include <iostream>

using namespace std;

main()
{
int count = 0;
int user;
int odd = 0;
int even = 0;


cout << "Enter a positive integer: ";
cin >> user;

while(user >= 0)
{
	if(user%2 == 0)
	{
		even = even + user;
	}else
	{
		odd = odd + user;
	}
	
	cout << "Enter a positive integer: ";
    cin >> user;
	
}

cout << "Result even : "<< even;
cout << "Result odd : "<< odd;


	
}
