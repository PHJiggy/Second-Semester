#include <iostream>

using namespace std;

main()
{
	int counter = 1;
	int count = 1; 
	cout << ++counter << " ";
	
	cout << count++ << " "; 
}
