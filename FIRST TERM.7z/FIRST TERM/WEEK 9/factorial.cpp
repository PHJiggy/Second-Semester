#include <iostream>
/*$$\   $$\ $$\     $$\ $$\       $$$$$$$$\ 
$$ | $$  |\$$\   $$  |$$ |      $$  _____|
$$ |$$  /  \$$\ $$  / $$ |      $$ |      
$$$$$  /    \$$$$  /  $$ |      $$$$$\    
$$  $$<      \$$  /   $$ |      $$  __|   
$$ |\$$\      $$ |    $$ |      $$ |      
$$ | \$$\     $$ |    $$$$$$$$\ $$$$$$$$\ 
\__|  \__|    \__|    \________|\________|
                                          
                                          */                                        
using namespace std;
main()
{

int number;
int factorial;
int count;
int trial = 0;

while(trial < 3)
{
	cout << "Enter a number: ";
	cin >> number;
	
	if(number == 0)
	{
	
	cout << "The factorial of 0 is 1. ";
} else
{
	factorial = 1;
	count = 1;
	
	while(count <= number)
	{
	
	
	factorial = factorial * count;
	++count;
}

++trial;
}
cout << factorial;

	
}

	
		
	}
