#include <iostream>

using namespace std;

main()
{
	int user_input;
	int add = 0;
	int number = 1;
	int counter = 0;
	int final;

	
	
	
		cout << "Enter the value: ";
	 	cin >> user_input;
		 
		 while(counter < user_input)
		 {
		 	
		 	add = add + number;
		 	final = final + add;
		 	++counter;
			 }	
			 
			 cout << " " << final;
}

