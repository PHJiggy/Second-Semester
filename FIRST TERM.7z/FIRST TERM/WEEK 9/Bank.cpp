#include <iostream>
using namespace std;

/*
$$$$$$$\                      $$\       
$$  __$$\                     $$ |      
$$ |  $$ | $$$$$$\  $$$$$$$\  $$ |  $$\ 
$$$$$$$\ | \____$$\ $$  __$$\ $$ | $$  |
$$  __$$\  $$$$$$$ |$$ |  $$ |$$$$$$  / 
$$ |  $$ |$$  __$$ |$$ |  $$ |$$  _$$<  
$$$$$$$  |\$$$$$$$ |$$ |  $$ |$$ | \$$\ 
\_______/  \_______|\__|  \__|\__|  \__|
                                        
                                         */
                                                                     
string password; //The password number of the user
string user; //The username of the user
int pick; //User input of selection of choice
int deposit; //deposit amount
int balance = 0; //total balance
int withdraw;

void login() {
    while (true) {
        cout << "\n[Login]" << endl;
        cout << "Enter the username: ";
        cin >> user;
        cout << "Password: ";
        cin >> password;

        // Identifier Log in
        if (user == "Kyle" && password == "123") {
            system("clear");
            cout << "Welcome Back! " << user;
            break;
        } else {
            system("cls");
            cout << "Invalid Account Please try again";
        }
    }
}

void choices() {
	while (true) {
        system("clear");
        cout << "\n[Menu]" << endl;
        cout << "[1] Deposit " << endl;
        cout << "[2] Withdraw " << endl;
        cout << "[3] Exit " << endl;
        cin >> pick;

        switch (pick) {
            case 1:
                cout << "Your amount is " << balance << endl;
                cout << "Enter the amount: ";
                cin >> deposit;
                if (deposit > 0) {
                    balance += deposit;
                    cout << "Your new balance is " << balance << " Pesos";
                } else {
                    cout << "Invalid amount!";
                }
                break;

            case 2:
                cout << "Enter the amount to withdraw: ";
                cin >> withdraw;
                if (withdraw > 0 && withdraw <= balance) {
                    balance -= withdraw;
                    cout << "The new balance is " << balance << " Pesos";
                } else {
                    cout << "Invalid amount or insufficient balance!";
                }
                break;

            case 3:
                cout << "Exiting...";
                exit(0);

            default:
                cout << "Invalid choice!";
        }
    }

}

int main() {
    login();
    choices();
    
    return 0;
}



