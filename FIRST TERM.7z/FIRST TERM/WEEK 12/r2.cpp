#include <iostream>

using namespace std;

int count(int k)
{
	if(k != 0)
	{
		cout << k << ". "<< endl;
		count(k - 1);
	}
}


main()
{
	
	int countD = count(5);
	
}
