#include <iostream>

using namespace std;




int sum(int k) {
  if (k > 0) { 
  cout << k << ".";
    sum(k - 1);
    
  } else {
    cout << "Done";
    exit(0);
  }
}



int main() {
  int result = sum(10);
  

  cout << result;
  return 0;
}


