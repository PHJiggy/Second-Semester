#include <iostream>

using namespace std;

/*#define F_HOUR = 500
#define OVERTIME = 1.5
#define TAX = 0.015
#define CONT = 0.03
#define PIT = 0.1
#define HEALTH = 300 */

float user_hour()
{
	int hour;
	cout << "Hour 		:  ";
	cin >> hour;
	
	return hour;
}

float user_dependent()
{
	int dependent;
	cout << "Dependent 	:  ";
	cin >> dependent;
	
	
	return dependent;
}



float gross(float user_hr, float user_dep)
{
	const float F_HOUR = 500;
	const float OVERTIME = 1.5;
	float gross_total;
	if(user_hr > 40)
	{
		gross_total = 40*F_HOUR + (user_hr-40) * F_HOUR * (OVERTIME);
		
	} else
	{
		gross_total = user_hr * F_HOUR;
	}
	
	return gross_total;
}

float sss(float gross_total)
{
	const float cont = 0.03;
	
	float sss_total;
	sss_total = gross_total * cont;
	
	return sss_total;
}

main()
{
	float ssss;
	float user_hr; // hours
	float user_dep; // dependent
	float gross_T; // gross total
	user_hr  = user_hour();
	user_dep = user_dependent();
	
	system("CLS");
	gross_T = gross(user_hr, user_dep); // gross function
	cout << "The Sahod	: "<< gross_T << endl;
	
	ssss = sss(gross_T); // sss function
	cout << "SSS	: " << ssss;
	
	
}
	
	
	
	
	

