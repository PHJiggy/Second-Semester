#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include <cstdlib>

using namespace std;

int count(int k)
{
	while(k != 0)
	{
		Sleep(1000);
		cout << k << " ";
	--k;
	}
		cout << "Done!";
	
}


main()
{
	
	int countD = count(1000);
	
}
