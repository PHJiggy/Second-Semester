#include <iostream>

using namespace std;

int main()
{
	float a;
	int x;
	int y;
	int z;
	cout << "Val x: ";
	cin >> x;
	
	cout << "Val y: ";
	cin >> y;
	
	cout << "val z: ";
	cin >> z;
	
	a = (3*x+y)/(z+2);
	
	cout << "The value  of a is " << a;
	
}

