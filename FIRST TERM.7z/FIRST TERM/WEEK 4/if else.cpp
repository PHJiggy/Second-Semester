#include <iostream>

using namespace std;

int main()
{
	int num_1, num_2, larger;
	
	cout << "Enter the first number: " << endl;
	cin >> num_1;
	cout << "Enter the second number: " << endl;
	cin >> num_2;
	
	if(num_1 > num_2)
	{
	
		larger = num_1;
	}
	if(num_2 > num_1)
	{
	
		larger = num_2;
	}
	cout << "The larger number is " << larger <<".";
	
	
	
}
