#include <iostream>

using namespace std;

int main()
{
	const int Foot = 12;
	const float meter = 0.0254;
	const float kilogram = 2.2;
	
	float feet, inches, weight;
	
	cout << "Feet: " << endl;
	cin >> feet;
	cout << "Inches: " << endl;
	cin >> inches;
	cout << "Weight: " << endl;
	cin >> weight;
	
	float H_feet = feet * Foot + inches;
	float F_meter = H_feet * meter;
	float W_kilogram = weight / kilogram;
	float BMI =  W_kilogram/(F_meter*F_meter);
	
	cout << "\nYour Height: " << F_meter << endl; 
	cout << "Kilogram   : " << W_kilogram << endl;
	cout << "BMI        : " << BMI << endl;
	
	
	
	
	
	
}
