#include <iostream>
#include <string>
using namespace std;

int main()
{
	int a,b,c,d;
	
	c = 1; d = 1;
	a = ++c; b = d++;
	
	cout << a << b << c << d;
	
	 
	float num;
	float num1 ; 
	
	cout << "\nHat dog: " << endl;
	cin >> num;
	
	cout << num;
	
}
