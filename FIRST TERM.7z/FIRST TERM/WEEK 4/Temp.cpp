#include <iostream>

using namespace std;

int main()
{
       float f;
	   float c;
	   
	   cout << "C; ";
	   cin >> c;
	  
	  //&& this symboll is and, || this is or
	  f=(9*c)/5+32;
	  
	  cout << f;	
	
}
