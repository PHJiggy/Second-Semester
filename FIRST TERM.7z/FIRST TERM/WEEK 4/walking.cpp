#include <iostream>
#include <algorithm>
#include <iterator>
#include <sys/stat.h>
#include <dirent.h>
#include <queue>
#include <regex>

namespace stroll {

	using namespace std;
	
	typedef unsigned int uint;
	typedef vector<string> vstr;
	
	void st(const string path1, const string path2, struct stat *st1, struct stat *st2){
		if(stat(path1.c_str(),st1) == -1){
			exit(-1);
		}
		if(stat(path2.c_str(),st2) == -1){
			exit(-1);
		}
	}
	
	bool sortByMtime(const string path1, const string path2){
		struct stat st1, st2;
		st(path1,path2,&st1,&st2);
		return st1.st_mtime < st2.st_mtime;
	}
	
	bool sortByMtimeDesc(const string path1, const string path2){
		struct stat st1, st2;
		st(path1,path2,&st1,&st2);
		return st1.st_mtime > st2.st_mtime;
	}
	
	bool sortByLen(const string path1, const string path2){
		return path1.size() < path2.size();
	}
	
	bool sortByLenDesc(const string path1, const string path2){
		return path1.size() > path2.size();
	}
	
	bool sortByName(const string path1, const string path2){
		return path1 < path2;
	}
	
	bool sortByNameDesc(const string path1, const string path2){
		return path1 > path2;
	}

	class Stroll{
	
		DIR *dir;
		struct dirent *dp;
		string topdir;
		string current;
		vstr files;
		vstr dirs;
		vstr no_path;
		vstr yes_path;
		vstr no_root;
		vstr yes_root;
		vstr no_file;
		vstr yes_file;
		bool (*sortby)(string, string);
	
		public:
		bool read(){
			while(files.size()==0){
				string basedir = "";
				if(dirs.size()==0){
					return false;
				}else{
					basedir = dirs.front();
					dirs.erase(dirs.begin());
				}
	
				dir = opendir(basedir.c_str());
				if(dir==NULL){
					return false;
				}
		
				for(dp=readdir(dir);dp!=NULL;dp=readdir(dir)){
					if((string)dp->d_name=="." || (string)dp->d_name=="..")
						continue;
	
					struct stat st;
					string filename = (string)dp->d_name;
					string path = basedir+"/"+filename;
					stat(path.c_str(),&st);
		
					if((st.st_mode & S_IFMT) == S_IFREG){
						if(is_no_file(path) && is_yes_file(path)){
							files.push_back(path);
						}
					}else if((st.st_mode & S_IFMT) == S_IFDIR){
						if(is_no_path(path) && is_yes_path(path)){
							if(is_no_root(filename) && is_yes_root(filename)){
								dirs.push_back(path);
							}
						}
					}else{
						// Not supported
						continue;
					}
				}
				sort(dirs.begin(),dirs.end(),sortby);
				sort(files.begin(),files.end(),sortby);
			}
	
			current = get_path();
			return true;
		}
	
		bool is_no_root(string root){
			if(no_root.size()==0) return true;
			for(uint i=0;i<no_root.size();i++){
				regex re(no_root[i]);
				if( regex_search(root,re) ){
					return false;
				}
			}
			return true;
		}
	
		bool is_yes_root(string root){
			if(yes_root.size()==0) return true;
			for(uint i=0;i<yes_root.size();i++){
				regex re(yes_root[i]);
				if( regex_search(root,re) ){
					return true;
				}
			}
			return false;
		}
	
		bool is_no_path(string path){
			if(no_path.size()==0) return true;
			for(uint i=0;i<no_path.size();i++){
				regex re(no_path[i]);
				if( regex_search(path,re) ){
					return false;
				}
			}
			return true;
		}
	
		bool is_yes_path(string path){
			if(yes_path.size()==0) return true;
			for(uint i=0;i<yes_path.size();i++){
				regex re(yes_path[i]);
				if( regex_search(path,re) ){
					return true;
				}
			}
			return false;
		}
	
		bool is_no_file(string path){
			if(no_file.size()==0) return true;
			for(uint i=0;i<no_file.size();i++){
				regex re(no_file[i]);
				if( regex_search(path,re) ){
					return false;
				}
			}
			return true;
		}
	
		bool is_yes_file(string path){
			if(yes_file.size()==0) return true;
			for(uint i=0;i<yes_file.size();i++){
				regex re(yes_file[i]);
				if( regex_search(path,re) ){
					return true;
				}
			}
			return false;
		}
	
		string get_path(){
			string file = files.front();
			files.erase(files.begin());
			return file;
		}
	
		string get(){
			return current;
		}
	
		void set_sortby(bool (*sortby)(string,string)){
			this->sortby = sortby;
		}
	
		void set_no_path(vstr no_path){
			this->no_path = no_path;
		}
	
		void set_yes_path(vstr yes_path){
			this->yes_path = yes_path;
		}
	
		void set_no_root(vstr no_root){
			this->no_root = no_root;
		}
	
		void set_yes_root(vstr yes_root){
			this->yes_root = yes_root;
		}
	
		void set_no_file(vstr no_file){
			this->no_file = no_file;
		}
	
		void set_yes_file(vstr yes_file){
			this->yes_file = yes_file;
		}
	
	
		Stroll(string topdir,vstr no_path, vstr yes_path, vstr no_root, vstr yes_root, vstr no_file, vstr yes_file, bool (*sortby)(string,string)):topdir(topdir),no_path(no_path),yes_path(yes_path),no_root(no_root),yes_root(yes_root),no_file(no_file),yes_file(yes_file),sortby(sortby){
			dirs.push_back(topdir);
		}
	
		Stroll(string topdir):topdir(topdir){
			dirs.push_back(topdir);
			sortby = sortByName;
		}
	};
	
}
