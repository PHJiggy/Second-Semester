#include <iostream>

using namespace std;

int main()
{
	int U_second;
	int second = 60;
	int minute = 60;
	int hours = 24;
	int day = second * minute * hours;
	int F_hours = second * minute;
	
	
	

	

	cout << "Second: " << endl;
	cin >> U_second; 
	
	int R_day = U_second / day;
	int R_hours = U_second / F_hours % hours;
	int R_minute = U_second / minute % minute; 
	int R_second = U_second % second ;
	cout << "\nUser input: " << U_second << " Day: " << R_day  << " Hours: " << R_hours << " Minutes: " << R_minute << " Seconds: " << R_second  << endl;
}
