#include <iostream>

using namespace std;

main()
{
	
int jan = 1;
int feb = 2;
int march = 3;
int april = 4;
int may  = 5;
int june = 6;
int july = 7;
int aug = 8;
int sept = 9;
int oct = 10;
int nov = 11;
int dec = 12;

int day;
int month;
while(true)

{


cout << "day: " << endl;
cin >> day;
cout << "month: " << endl;
cin >> month;
while(true)
{

if(day <=31 && month == 3)
{
cout << "Aries ka pre "<< endl;	
}else if(day <= 19 && month == 4)
{
	cout << " Aries ka pre " << endl;
}else if(day >= 20 && month == 4 )
{
	cout << " Taurus ka pre " << endl;
	
}else if(day <= 20 && month == 5 )
{
	cout << " Taurus ka pre " << endl;
}else if(day >= 21 && month == 5 )
{

cout << " Gemini ka pre " << endl;

}else if(day <= 21 && month == 6 )
{
	cout << " Gemini ka pre " << endl;
}

cout << "day: " << endl;
cin >> day;
cout << "month: " << endl;
cin >> month;

}
}
}
