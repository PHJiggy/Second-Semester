#include <iostream>

//$$\   $$\ $$\     $$\ $$\       $$$$$$$$\ 
//$$ | $$  |\$$\   $$  |$$ |      $$  _____|
//$$ |$$  /  \$$\ $$  / $$ |      $$ |      
//$$$$$  /    \$$$$  /  $$ |      $$$$$\    
//$$  $$<      \$$  /   $$ |      $$  __|   
//$$ |\$$\      $$ |    $$ |      $$ |      
//$$ | \$$\     $$ |    $$$$$$$$\ $$$$$$$$\ 
//\__|  \__|    \__|    \________|\________|

using namespace std;

main()
{
	int trial = 1;
	int pre;
	cout << "Pre number Mo: " << endl;
	cin >> pre;
	

	
	while((pre < 5 || pre > 10) && (trial < 5))
	{
		cout << " Hoy! Between 5 and 10 lang! " << endl;
	
	cout << "\nUlit! (Between 5 and 10 lang!!!!): " << endl;
	cin >> pre;
	
	++trial;
	
	if(trial == 3)
	{
		cout << "Pangatlo nayan pre, AYOSIN MO!!!" << endl;
	}
}
	
	
	if(trial == 5)
	{
		cout << " Agoy pre read the instruction carefully ";
	}else if(pre > 5 || pre < 10)
	{
		cout << "You have wise choice " << pre;
	}
	
	
}




                                          
                                          
                                          
