#include <iostream>
#include <string>

using namespace std;

main()
{
	

string txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
cout << "The length of the txt string is: " << txt.length();

}
